import logging
import boto3
from botocore.exceptions import ClientError
import pymysql
import os
import json 
import csv
logger = logging.getLogger()
logger.setLevel(logging.INFO)
# rds settings
user_name = 'admin'
password = 'testpassword'
rds_proxy_host = 'proxy-1701925589163-database-1.proxy-c3tca0a5cslt.us-east-2.rds.amazonaws.com'
db_name = 'ProjectDB'


# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
	conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
	logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")
except pymysql.MySQLError as e:
	logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
	logger.error(e)
	
	
#cloud_function(platforms=[Platform.AWS], memory=512, config=config)
def yourFunction(request, context):
	import time
	filters = []
	#FILTERS
	if 'Region' in request:
		filters += "Region = " + request['Region']
	if 'ItemType' in request:
		filters += "ItemType = " + request['ItemType']
	if 'SalesChannel' in request:
		filters += "SalesChannel = " + request['SalesChannel']
	if 'OrderPriority' in request:
		filters += "OrderPriority = " + request['OrderPriority']
	aggregate = []
	#AGGREGATE
	if 'Sum' in request:
		aggregate += "SUM("+request['Sum']+") AS Sum"+request['Sum']
	if 'Avg' in request:
		aggregate += "AVG("+request['Avg']+") AS Avg"+request['Avg']
	if 'Max' in request:
		aggregate += "Max("+request['Max']+") AS Max"+request['Max']
	if 'Min' in request:
		aggregate += "Min("+request['Min']+") AS Min"+request['Min'] 
	sql_string = "Select "
	if len(aggregate) == 0:
		return {"Error":"Must include an aggregation metric (Sum, Avg, Max, Min)"}
	for line in aggregate:
		sql_string += line + ","
	sql_string = sql_string[:-1]
	if len(filters) > 0:
		sql_string += " WHERE "
		for line in filters:
			sql_string += line + " AND "
		sql_string = sql_string[:-5]
	with conn.cursor() as cur:
		cur.execute(sql_string)
		conn.commit()
	conn.commit()
	return {cur}
